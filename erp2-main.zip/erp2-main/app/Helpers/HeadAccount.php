<?php

namespace App\Helpers;

interface HeadAccount
{
  const RIDER = 1;
  const BANK = 994;
  const SALARY_ACCOUNT = 1103;
  const TAX_ACCOUNT = 1023;
  const ADVANCE_LOAN = 1135;



}

?>
