<?php
// Variables
return [
  "creatorName" => "LimeCircles",
  "creatorUrl" => "https://limecircles.com",
  "templateName" => "Express Fast",
  "templateSuffix" => "Express Fast",
  "templateVersion" => "1.0.0",
  "templateFree" => false,
  "templateDescription" => "Express Fast",
  "templateKeyword" => "Express Fast",
  "licenseUrl" => "https://themeforest.net/licenses/standard",
  "livePreview" => "https://demos.pixinvent.com/vuexy-html-admin-template/landing/",
  "productPage" => "https://limecircles.com",
  "support" => "https://pixinvent.ticksy.com/",
  "moreThemes" => "https://1.envato.market/pixinvent_portfolio",
  "documentation" => "https://demos.pixinvent.com/vuexy-html-admin-template/documentation",
  "generator" => "",
  "changelog" => "https://demos.pixinvent.com/vuexy/changelog.html",
  "repository" => "https://github.com/pixinvent/vuexy-html-admin-template",
  "gitRepo" => "limecircles",
  "gitRepoAccess" => "vuexy-html-admin-template",
  "githubFreeUrl" => "https://tools.pixinvent.com/github/github-access",
  "facebookUrl" => "https://www.facebook.com/pixinvents/",
  "twitterUrl" => "https://twitter.com/pixinvents",
  "githubUrl" => "https://github.com/pixinvent",
  "dribbbleUrl" => "https://dribbble.com/pixinvent",
  "instagramUrl" => "https://www.instagram.com/pixinvents/"
];
