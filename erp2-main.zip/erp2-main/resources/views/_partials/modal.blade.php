

  <div class="modal modal-default fade" id="modalTop" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalTopTitle">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="modalTopbody" style="min-height: 200px;">
           {{--  <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
              </div> --}}
        </div>
        <div class="modal-footer">
         {{--  <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save</button> --}}
        </div>
    </div>
    </div>
  </div>

 

 