
                <div class="row">
                    @include('banks.show_fields')
                </div>
