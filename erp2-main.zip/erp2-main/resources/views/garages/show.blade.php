
                <div class="row">
                    @include('garages.show_fields')
                </div>
