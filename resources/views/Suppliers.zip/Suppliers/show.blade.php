@extends('layouts.app')
@section('title', 'Suppliers')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Supplier Details</h1>
                </div>
               
            </div>
        </div>
    </section>

    <div class="content px-3">
    <ul class="nav nav-tabs mb-3" id="supplierTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab">
      Information
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="ledger-tab" data-bs-toggle="tab" data-bs-target="#ledger" type="button" role="tab">
      Ledger
    </button>
  </li>
</ul>

<div class="tab-content" id="supplierTabContent" style="background:none;">
  <!-- Info Tab -->
  <div class="tab-pane fade show active" id="info" role="tabpanel">
    <div class="card p-4 shadow-sm">
      <div class="row">
        <div class="col-md-3 form-group col-3">
          <label>Supplier Name:</label>
          <p> {{ $supplier->name }}</p>
        </div>
          <div class="col-md-3 form-group col-3">
          <label>Email:</label>
          <p> {{ $supplier->email }}</p>
        </div>
        <div class="col-md-3 form-group col-3">
          <label>Phone:</label>
           <p>{{ $supplier->phone }}</p>
        </div>
        <div class="col-md-3 form-group col-3">
          <label>Address:</label>
           <p>{{ $supplier->address }}</p>
        </div>
      </div>
      
    </div>
    <div class="col-sm-6">
    <a href="{{ route('suppliers.index') }}" class="btn btn-primary float-right">Back</a>
    </div>
  </div>

  <!-- Ledger Tab -->
  <div class="tab-pane fade" id="ledger" role="tabpanel">
    <div class="card p-4 shadow-sm">
      <h5>Ledger</h5>
      @include('suppliers.ledger')
    </div>
  </div>
</div>
    </div>
@endsection